class StaticPageController < ApplicationController
  def home
  end

  def help
  end
end
